"use client";
import {
  IconBase,
  Portal,
  Ripple
} from "./chunk-A4CIDHKT.js";
import {
  ComponentBase,
  DomHandler,
  ESC_KEY_HANDLING_PRIORITIES,
  IconUtils,
  ObjectUtils,
  PrimeReact,
  PrimeReactContext,
  ZIndexUtils,
  classNames,
  useDisplayOrder,
  useGlobalOnEscapeKey,
  useHandleStyle,
  useMergeProps,
  useMountEffect,
  useOverlayScrollListener,
  useResizeListener,
  useUnmountEffect,
  useUpdateEffect
} from "./chunk-CRNYF24F.js";
import "./chunk-AU2MKR2E.js";
import {
  require_react
} from "./chunk-VX2H6PUQ.js";
import {
  __toESM
} from "./chunk-G3PMV62Z.js";

// node_modules/primereact/button/button.esm.js
var React3 = __toESM(require_react());

// node_modules/primereact/icons/spinner/index.esm.js
var React = __toESM(require_react());
function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var SpinnerIcon = React.memo(React.forwardRef(function(inProps, ref) {
  var pti = IconBase.getPTI(inProps);
  return React.createElement("svg", _extends({
    ref,
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, pti), React.createElement("path", {
    d: "M6.99701 14C5.85441 13.999 4.72939 13.7186 3.72012 13.1832C2.71084 12.6478 1.84795 11.8737 1.20673 10.9284C0.565504 9.98305 0.165424 8.89526 0.041387 7.75989C-0.0826496 6.62453 0.073125 5.47607 0.495122 4.4147C0.917119 3.35333 1.59252 2.4113 2.46241 1.67077C3.33229 0.930247 4.37024 0.413729 5.4857 0.166275C6.60117 -0.0811796 7.76026 -0.0520535 8.86188 0.251112C9.9635 0.554278 10.9742 1.12227 11.8057 1.90555C11.915 2.01493 11.9764 2.16319 11.9764 2.31778C11.9764 2.47236 11.915 2.62062 11.8057 2.73C11.7521 2.78503 11.688 2.82877 11.6171 2.85864C11.5463 2.8885 11.4702 2.90389 11.3933 2.90389C11.3165 2.90389 11.2404 2.8885 11.1695 2.85864C11.0987 2.82877 11.0346 2.78503 10.9809 2.73C9.9998 1.81273 8.73246 1.26138 7.39226 1.16876C6.05206 1.07615 4.72086 1.44794 3.62279 2.22152C2.52471 2.99511 1.72683 4.12325 1.36345 5.41602C1.00008 6.70879 1.09342 8.08723 1.62775 9.31926C2.16209 10.5513 3.10478 11.5617 4.29713 12.1803C5.48947 12.7989 6.85865 12.988 8.17414 12.7157C9.48963 12.4435 10.6711 11.7264 11.5196 10.6854C12.3681 9.64432 12.8319 8.34282 12.8328 7C12.8328 6.84529 12.8943 6.69692 13.0038 6.58752C13.1132 6.47812 13.2616 6.41667 13.4164 6.41667C13.5712 6.41667 13.7196 6.47812 13.8291 6.58752C13.9385 6.69692 14 6.84529 14 7C14 8.85651 13.2622 10.637 11.9489 11.9497C10.6356 13.2625 8.85432 14 6.99701 14Z",
    fill: "currentColor"
  }));
}));
SpinnerIcon.displayName = "SpinnerIcon";

// node_modules/primereact/tooltip/tooltip.esm.js
var React2 = __toESM(require_react());
function _extends2() {
  return _extends2 = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends2.apply(null, arguments);
}
function _typeof(o) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
    return typeof o2;
  } : function(o2) {
    return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
  }, _typeof(o);
}
function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: true,
    configurable: true,
    writable: true
  }) : e[r] = t, e;
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return _arrayLikeToArray(r);
}
function _iterableToArray(r) {
  if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _toConsumableArray(r) {
  return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
}
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}
function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e, n, i, u, a = [], f = true, o = false;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = false;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = true) ;
    } catch (r2) {
      o = true, n = r2;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
var classes = {
  root: function root(_ref) {
    var positionState = _ref.positionState, classNameState = _ref.classNameState;
    return classNames("p-tooltip p-component", _defineProperty({}, "p-tooltip-".concat(positionState), true), classNameState);
  },
  arrow: "p-tooltip-arrow",
  text: "p-tooltip-text"
};
var inlineStyles = {
  arrow: function arrow(_ref2) {
    var context = _ref2.context;
    return {
      top: context.bottom ? "0" : context.right || context.left || !context.right && !context.left && !context.top && !context.bottom ? "50%" : null,
      bottom: context.top ? "0" : null,
      left: context.right || !context.right && !context.left && !context.top && !context.bottom ? "0" : context.top || context.bottom ? "50%" : null,
      right: context.left ? "0" : null
    };
  }
};
var styles = "\n@layer primereact {\n    .p-tooltip {\n        position: absolute;\n        padding: .25em .5rem;\n        /* #3687: Tooltip prevent scrollbar flickering */\n        top: -9999px;\n        left: -9999px;\n    }\n    \n    .p-tooltip.p-tooltip-right,\n    .p-tooltip.p-tooltip-left {\n        padding: 0 .25rem;\n    }\n    \n    .p-tooltip.p-tooltip-top,\n    .p-tooltip.p-tooltip-bottom {\n        padding:.25em 0;\n    }\n    \n    .p-tooltip .p-tooltip-text {\n       white-space: pre-line;\n       word-break: break-word;\n    }\n    \n    .p-tooltip-arrow {\n        position: absolute;\n        width: 0;\n        height: 0;\n        border-color: transparent;\n        border-style: solid;\n    }\n    \n    .p-tooltip-right .p-tooltip-arrow {\n        top: 50%;\n        left: 0;\n        margin-top: -.25rem;\n        border-width: .25em .25em .25em 0;\n    }\n    \n    .p-tooltip-left .p-tooltip-arrow {\n        top: 50%;\n        right: 0;\n        margin-top: -.25rem;\n        border-width: .25em 0 .25em .25rem;\n    }\n    \n    .p-tooltip.p-tooltip-top {\n        padding: .25em 0;\n    }\n    \n    .p-tooltip-top .p-tooltip-arrow {\n        bottom: 0;\n        left: 50%;\n        margin-left: -.25rem;\n        border-width: .25em .25em 0;\n    }\n    \n    .p-tooltip-bottom .p-tooltip-arrow {\n        top: 0;\n        left: 50%;\n        margin-left: -.25rem;\n        border-width: 0 .25em .25rem;\n    }\n\n    .p-tooltip-target-wrapper {\n        display: inline-flex;\n    }\n}\n";
var TooltipBase = ComponentBase.extend({
  defaultProps: {
    __TYPE: "Tooltip",
    appendTo: null,
    at: null,
    autoHide: true,
    autoZIndex: true,
    baseZIndex: 0,
    className: null,
    closeOnEscape: false,
    content: null,
    disabled: false,
    event: null,
    hideDelay: 0,
    hideEvent: "mouseleave",
    id: null,
    mouseTrack: false,
    mouseTrackLeft: 5,
    mouseTrackTop: 5,
    my: null,
    onBeforeHide: null,
    onBeforeShow: null,
    onHide: null,
    onShow: null,
    position: "right",
    showDelay: 0,
    showEvent: "mouseenter",
    showOnDisabled: false,
    style: null,
    target: null,
    updateDelay: 0,
    children: void 0
  },
  css: {
    classes,
    styles,
    inlineStyles
  }
});
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
      _defineProperty(e, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
      Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e;
}
var Tooltip = React2.memo(React2.forwardRef(function(inProps, ref) {
  var mergeProps = useMergeProps();
  var context = React2.useContext(PrimeReactContext);
  var props = TooltipBase.getProps(inProps, context);
  var _React$useState = React2.useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), visibleState = _React$useState2[0], setVisibleState = _React$useState2[1];
  var _React$useState3 = React2.useState(props.position || "right"), _React$useState4 = _slicedToArray(_React$useState3, 2), positionState = _React$useState4[0], setPositionState = _React$useState4[1];
  var _React$useState5 = React2.useState(""), _React$useState6 = _slicedToArray(_React$useState5, 2), classNameState = _React$useState6[0], setClassNameState = _React$useState6[1];
  var _React$useState7 = React2.useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), multipleFocusEvents = _React$useState8[0], setMultipleFocusEvents = _React$useState8[1];
  var isCloseOnEscape = visibleState && props.closeOnEscape;
  var overlayDisplayOrder = useDisplayOrder("tooltip", isCloseOnEscape);
  var metaData = {
    props,
    state: {
      visible: visibleState,
      position: positionState,
      className: classNameState
    },
    context: {
      right: positionState === "right",
      left: positionState === "left",
      top: positionState === "top",
      bottom: positionState === "bottom"
    }
  };
  var _TooltipBase$setMetaD = TooltipBase.setMetaData(metaData), ptm = _TooltipBase$setMetaD.ptm, cx = _TooltipBase$setMetaD.cx, sx = _TooltipBase$setMetaD.sx, isUnstyled = _TooltipBase$setMetaD.isUnstyled;
  useHandleStyle(TooltipBase.css.styles, isUnstyled, {
    name: "tooltip"
  });
  useGlobalOnEscapeKey({
    callback: function callback() {
      hide();
    },
    when: isCloseOnEscape,
    priority: [ESC_KEY_HANDLING_PRIORITIES.TOOLTIP, overlayDisplayOrder]
  });
  var elementRef = React2.useRef(null);
  var textRef = React2.useRef(null);
  var currentTargetRef = React2.useRef(null);
  var containerSize = React2.useRef(null);
  var allowHide = React2.useRef(true);
  var timeouts = React2.useRef({});
  var currentMouseEvent = React2.useRef(null);
  var _useResizeListener = useResizeListener({
    listener: function listener(event) {
      !DomHandler.isTouchDevice() && hide(event);
    }
  }), _useResizeListener2 = _slicedToArray(_useResizeListener, 2), bindWindowResizeListener = _useResizeListener2[0], unbindWindowResizeListener = _useResizeListener2[1];
  var _useOverlayScrollList = useOverlayScrollListener({
    target: currentTargetRef.current,
    listener: function listener(event) {
      hide(event);
    },
    when: visibleState
  }), _useOverlayScrollList2 = _slicedToArray(_useOverlayScrollList, 2), bindOverlayScrollListener = _useOverlayScrollList2[0], unbindOverlayScrollListener = _useOverlayScrollList2[1];
  var isTargetContentEmpty = function isTargetContentEmpty2(target) {
    return !(props.content || getTargetOption(target, "tooltip"));
  };
  var isContentEmpty = function isContentEmpty2(target) {
    return !(props.content || getTargetOption(target, "tooltip") || props.children);
  };
  var isMouseTrack = function isMouseTrack2(target) {
    return getTargetOption(target, "mousetrack") || props.mouseTrack;
  };
  var isDisabled = function isDisabled2(target) {
    return getTargetOption(target, "disabled") === "true" || hasTargetOption(target, "disabled") || props.disabled;
  };
  var isShowOnDisabled = function isShowOnDisabled2(target) {
    return getTargetOption(target, "showondisabled") || props.showOnDisabled;
  };
  var isAutoHide = function isAutoHide2() {
    return getTargetOption(currentTargetRef.current, "autohide") || props.autoHide;
  };
  var getTargetOption = function getTargetOption2(target, option) {
    return hasTargetOption(target, "data-pr-".concat(option)) ? target.getAttribute("data-pr-".concat(option)) : null;
  };
  var hasTargetOption = function hasTargetOption2(target, option) {
    return target && target.hasAttribute(option);
  };
  var getEvents = function getEvents2(target) {
    var showEvents = [getTargetOption(target, "showevent") || props.showEvent];
    var hideEvents = [getTargetOption(target, "hideevent") || props.hideEvent];
    if (isMouseTrack(target)) {
      showEvents = ["mousemove"];
      hideEvents = ["mouseleave"];
    } else {
      var event = getTargetOption(target, "event") || props.event;
      if (event === "focus") {
        showEvents = ["focus"];
        hideEvents = ["blur"];
      }
      if (event === "both") {
        showEvents = ["focus", "mouseenter"];
        hideEvents = multipleFocusEvents ? ["blur"] : ["mouseleave", "blur"];
      }
    }
    return {
      showEvents,
      hideEvents
    };
  };
  var getPosition = function getPosition2(target) {
    return getTargetOption(target, "position") || positionState;
  };
  var getMouseTrackPosition = function getMouseTrackPosition2(target) {
    var top = getTargetOption(target, "mousetracktop") || props.mouseTrackTop;
    var left = getTargetOption(target, "mousetrackleft") || props.mouseTrackLeft;
    return {
      top,
      left
    };
  };
  var updateText = function updateText2(target, callback) {
    if (textRef.current) {
      var content = getTargetOption(target, "tooltip") || props.content;
      if (content) {
        textRef.current.innerHTML = "";
        textRef.current.appendChild(document.createTextNode(content));
        callback();
      } else if (props.children) {
        callback();
      }
    }
  };
  var updateTooltipState = function updateTooltipState2(position) {
    updateText(currentTargetRef.current, function() {
      var _currentMouseEvent$cu = currentMouseEvent.current, x = _currentMouseEvent$cu.pageX, y = _currentMouseEvent$cu.pageY;
      if (props.autoZIndex && !ZIndexUtils.get(elementRef.current)) {
        ZIndexUtils.set("tooltip", elementRef.current, context && context.autoZIndex || PrimeReact.autoZIndex, props.baseZIndex || context && context.zIndex.tooltip || PrimeReact.zIndex.tooltip);
      }
      elementRef.current.style.left = "";
      elementRef.current.style.top = "";
      if (isAutoHide()) {
        elementRef.current.style.pointerEvents = "none";
      }
      var mouseTrackCheck = isMouseTrack(currentTargetRef.current) || position === "mouse";
      if (mouseTrackCheck && !containerSize.current || mouseTrackCheck) {
        containerSize.current = {
          width: DomHandler.getOuterWidth(elementRef.current),
          height: DomHandler.getOuterHeight(elementRef.current)
        };
      }
      align(currentTargetRef.current, {
        x,
        y
      }, position);
    });
  };
  var show = function show2(e) {
    if (e.type && e.type === "focus") setMultipleFocusEvents(true);
    currentTargetRef.current = e.currentTarget;
    var disabled = isDisabled(currentTargetRef.current);
    var empty = isContentEmpty(isShowOnDisabled(currentTargetRef.current) && disabled ? currentTargetRef.current.firstChild : currentTargetRef.current);
    if (empty || disabled) {
      return;
    }
    currentMouseEvent.current = e;
    if (visibleState) {
      applyDelay("updateDelay", updateTooltipState);
    } else {
      var success = sendCallback(props.onBeforeShow, {
        originalEvent: e,
        target: currentTargetRef.current
      });
      if (success) {
        applyDelay("showDelay", function() {
          setVisibleState(true);
          sendCallback(props.onShow, {
            originalEvent: e,
            target: currentTargetRef.current
          });
        });
      }
    }
  };
  var hide = function hide2(e) {
    if (e && e.type === "blur") setMultipleFocusEvents(false);
    clearTimeouts();
    if (visibleState) {
      var success = sendCallback(props.onBeforeHide, {
        originalEvent: e,
        target: currentTargetRef.current
      });
      if (success) {
        applyDelay("hideDelay", function() {
          if (!isAutoHide() && allowHide.current === false) {
            return;
          }
          ZIndexUtils.clear(elementRef.current);
          DomHandler.removeClass(elementRef.current, "p-tooltip-active");
          setVisibleState(false);
          sendCallback(props.onHide, {
            originalEvent: e,
            target: currentTargetRef.current
          });
        });
      }
    } else if (!props.onBeforeHide && !getDelay("hideDelay")) {
      setVisibleState(false);
    }
  };
  var align = function align2(target, coordinate, position) {
    var left = 0;
    var top = 0;
    var currentPosition = position || positionState;
    if ((isMouseTrack(target) || currentPosition == "mouse") && coordinate) {
      var _containerSize = {
        width: DomHandler.getOuterWidth(elementRef.current),
        height: DomHandler.getOuterHeight(elementRef.current)
      };
      left = coordinate.x;
      top = coordinate.y;
      var _getMouseTrackPositio = getMouseTrackPosition(target), mouseTrackTop = _getMouseTrackPositio.top, mouseTrackLeft = _getMouseTrackPositio.left;
      switch (currentPosition) {
        case "left":
          left = left - (_containerSize.width + mouseTrackLeft);
          top = top - (_containerSize.height / 2 - mouseTrackTop);
          break;
        case "right":
        case "mouse":
          left = left + mouseTrackLeft;
          top = top - (_containerSize.height / 2 - mouseTrackTop);
          break;
        case "top":
          left = left - (_containerSize.width / 2 - mouseTrackLeft);
          top = top - (_containerSize.height + mouseTrackTop);
          break;
        case "bottom":
          left = left - (_containerSize.width / 2 - mouseTrackLeft);
          top = top + mouseTrackTop;
          break;
      }
      if (left <= 0 || containerSize.current.width > _containerSize.width) {
        elementRef.current.style.left = "0px";
        elementRef.current.style.right = window.innerWidth - _containerSize.width - left + "px";
      } else {
        elementRef.current.style.right = "";
        elementRef.current.style.left = left + "px";
      }
      elementRef.current.style.top = top + "px";
      DomHandler.addClass(elementRef.current, "p-tooltip-active");
    } else {
      var pos = DomHandler.findCollisionPosition(currentPosition);
      var my = getTargetOption(target, "my") || props.my || pos.my;
      var at = getTargetOption(target, "at") || props.at || pos.at;
      elementRef.current.style.padding = "0px";
      DomHandler.flipfitCollision(elementRef.current, target, my, at, function(calculatedPosition) {
        var _calculatedPosition$a = calculatedPosition.at, atX = _calculatedPosition$a.x, atY = _calculatedPosition$a.y;
        var myX = calculatedPosition.my.x;
        var newPosition = props.at ? atX !== "center" && atX !== myX ? atX : atY : calculatedPosition.at["".concat(pos.axis)];
        elementRef.current.style.padding = "";
        setPositionState(newPosition);
        updateContainerPosition(newPosition);
        DomHandler.addClass(elementRef.current, "p-tooltip-active");
      });
    }
  };
  var updateContainerPosition = function updateContainerPosition2(position) {
    if (elementRef.current) {
      var style = getComputedStyle(elementRef.current);
      if (position === "left") {
        elementRef.current.style.left = parseFloat(style.left) - parseFloat(style.paddingLeft) * 2 + "px";
      } else if (position === "top") {
        elementRef.current.style.top = parseFloat(style.top) - parseFloat(style.paddingTop) * 2 + "px";
      }
    }
  };
  var _onMouseEnter = function onMouseEnter() {
    if (!isAutoHide()) {
      allowHide.current = false;
    }
  };
  var _onMouseLeave = function onMouseLeave(e) {
    if (!isAutoHide()) {
      allowHide.current = true;
      hide(e);
    }
  };
  var bindTargetEvent = function bindTargetEvent2(target) {
    if (target) {
      var _getEvents = getEvents(target), showEvents = _getEvents.showEvents, hideEvents = _getEvents.hideEvents;
      var currentTarget = getTarget(target);
      showEvents.forEach(function(event) {
        return currentTarget === null || currentTarget === void 0 ? void 0 : currentTarget.addEventListener(event, show);
      });
      hideEvents.forEach(function(event) {
        return currentTarget === null || currentTarget === void 0 ? void 0 : currentTarget.addEventListener(event, hide);
      });
    }
  };
  var unbindTargetEvent = function unbindTargetEvent2(target) {
    if (target) {
      var _getEvents2 = getEvents(target), showEvents = _getEvents2.showEvents, hideEvents = _getEvents2.hideEvents;
      var currentTarget = getTarget(target);
      showEvents.forEach(function(event) {
        return currentTarget === null || currentTarget === void 0 ? void 0 : currentTarget.removeEventListener(event, show);
      });
      hideEvents.forEach(function(event) {
        return currentTarget === null || currentTarget === void 0 ? void 0 : currentTarget.removeEventListener(event, hide);
      });
    }
  };
  var getDelay = function getDelay2(delayProp) {
    return getTargetOption(currentTargetRef.current, delayProp.toLowerCase()) || props[delayProp];
  };
  var applyDelay = function applyDelay2(delayProp, callback) {
    clearTimeouts();
    var delay = getDelay(delayProp);
    delay ? timeouts.current["".concat(delayProp)] = setTimeout(function() {
      return callback();
    }, delay) : callback();
  };
  var sendCallback = function sendCallback2(callback) {
    if (callback) {
      for (var _len = arguments.length, params = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        params[_key - 1] = arguments[_key];
      }
      var result = callback.apply(void 0, params);
      if (result === void 0) {
        result = true;
      }
      return result;
    }
    return true;
  };
  var clearTimeouts = function clearTimeouts2() {
    Object.values(timeouts.current).forEach(function(t) {
      return clearTimeout(t);
    });
  };
  var getTarget = function getTarget2(target) {
    if (target) {
      if (isShowOnDisabled(target)) {
        if (!target.hasWrapper) {
          var wrapper = document.createElement("div");
          var isInputElement = target.nodeName === "INPUT";
          if (isInputElement) {
            DomHandler.addMultipleClasses(wrapper, "p-tooltip-target-wrapper p-inputwrapper");
          } else {
            DomHandler.addClass(wrapper, "p-tooltip-target-wrapper");
          }
          target.parentNode.insertBefore(wrapper, target);
          wrapper.appendChild(target);
          target.hasWrapper = true;
          return wrapper;
        }
        return target.parentElement;
      } else if (target.hasWrapper) {
        var _target$parentElement;
        (_target$parentElement = target.parentElement).replaceWith.apply(_target$parentElement, _toConsumableArray(target.parentElement.childNodes));
        delete target.hasWrapper;
      }
      return target;
    }
    return null;
  };
  var updateTargetEvents = function updateTargetEvents2(target) {
    unloadTargetEvents(target);
    loadTargetEvents(target);
  };
  var loadTargetEvents = function loadTargetEvents2(target) {
    setTargetEventOperations(target || props.target, bindTargetEvent);
  };
  var unloadTargetEvents = function unloadTargetEvents2(target) {
    setTargetEventOperations(target || props.target, unbindTargetEvent);
  };
  var setTargetEventOperations = function setTargetEventOperations2(target, operation) {
    target = ObjectUtils.getRefElement(target);
    if (target) {
      if (DomHandler.isElement(target)) {
        operation(target);
      } else {
        var setEvent = function setEvent2(target2) {
          var element2 = DomHandler.find(document, target2);
          element2.forEach(function(el) {
            operation(el);
          });
        };
        if (target instanceof Array) {
          target.forEach(function(t) {
            setEvent(t);
          });
        } else {
          setEvent(target);
        }
      }
    }
  };
  useMountEffect(function() {
    if (visibleState && currentTargetRef.current && isDisabled(currentTargetRef.current)) {
      hide();
    }
  });
  useUpdateEffect(function() {
    loadTargetEvents();
    return function() {
      unloadTargetEvents();
    };
  }, [show, hide, props.target]);
  useUpdateEffect(function() {
    if (visibleState) {
      var position = getPosition(currentTargetRef.current);
      var classname = getTargetOption(currentTargetRef.current, "classname");
      setPositionState(position);
      setClassNameState(classname);
      updateTooltipState(position);
      bindWindowResizeListener();
      bindOverlayScrollListener();
    } else {
      setPositionState(props.position || "right");
      setClassNameState("");
      currentTargetRef.current = null;
      containerSize.current = null;
      allowHide.current = true;
    }
    return function() {
      unbindWindowResizeListener();
      unbindOverlayScrollListener();
    };
  }, [visibleState]);
  useUpdateEffect(function() {
    var position = getPosition(currentTargetRef.current);
    if (visibleState && position !== "mouse") {
      applyDelay("updateDelay", function() {
        updateText(currentTargetRef.current, function() {
          align(currentTargetRef.current);
        });
      });
    }
  }, [props.content]);
  useUnmountEffect(function() {
    hide();
    ZIndexUtils.clear(elementRef.current);
  });
  React2.useImperativeHandle(ref, function() {
    return {
      props,
      updateTargetEvents,
      loadTargetEvents,
      unloadTargetEvents,
      show,
      hide,
      getElement: function getElement() {
        return elementRef.current;
      },
      getTarget: function getTarget2() {
        return currentTargetRef.current;
      }
    };
  });
  var createElement4 = function createElement5() {
    var empty = isTargetContentEmpty(currentTargetRef.current);
    var rootProps = mergeProps({
      id: props.id,
      className: classNames(props.className, cx("root", {
        positionState,
        classNameState
      })),
      style: props.style,
      role: "tooltip",
      "aria-hidden": visibleState,
      onMouseEnter: function onMouseEnter(e) {
        return _onMouseEnter();
      },
      onMouseLeave: function onMouseLeave(e) {
        return _onMouseLeave(e);
      }
    }, TooltipBase.getOtherProps(props), ptm("root"));
    var arrowProps = mergeProps({
      className: cx("arrow"),
      style: sx("arrow", _objectSpread({}, metaData))
    }, ptm("arrow"));
    var textProps = mergeProps({
      className: cx("text")
    }, ptm("text"));
    return React2.createElement("div", _extends2({
      ref: elementRef
    }, rootProps), React2.createElement("div", arrowProps), React2.createElement("div", _extends2({
      ref: textRef
    }, textProps), empty && props.children));
  };
  if (visibleState) {
    var element = createElement4();
    return React2.createElement(Portal, {
      element,
      appendTo: props.appendTo,
      visible: true
    });
  }
  return null;
}));
Tooltip.displayName = "Tooltip";

// node_modules/primereact/button/button.esm.js
function _extends3() {
  return _extends3 = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends3.apply(null, arguments);
}
function _typeof2(o) {
  "@babel/helpers - typeof";
  return _typeof2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
    return typeof o2;
  } : function(o2) {
    return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
  }, _typeof2(o);
}
function toPrimitive2(t, r) {
  if ("object" != _typeof2(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof2(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function toPropertyKey2(t) {
  var i = toPrimitive2(t, "string");
  return "symbol" == _typeof2(i) ? i : i + "";
}
function _defineProperty2(e, r, t) {
  return (r = toPropertyKey2(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: true,
    configurable: true,
    writable: true
  }) : e[r] = t, e;
}
var classes$1 = {
  root: function root2(_ref) {
    var props = _ref.props;
    return classNames("p-badge p-component", _defineProperty2({
      "p-badge-no-gutter": ObjectUtils.isNotEmpty(props.value) && String(props.value).length === 1,
      "p-badge-dot": ObjectUtils.isEmpty(props.value),
      "p-badge-lg": props.size === "large",
      "p-badge-xl": props.size === "xlarge"
    }, "p-badge-".concat(props.severity), props.severity !== null));
  }
};
var styles2 = "\n@layer primereact {\n    .p-badge {\n        display: inline-block;\n        border-radius: 10px;\n        text-align: center;\n        padding: 0 .5rem;\n    }\n    \n    .p-overlay-badge {\n        position: relative;\n    }\n    \n    .p-overlay-badge .p-badge {\n        position: absolute;\n        top: 0;\n        right: 0;\n        transform: translate(50%,-50%);\n        transform-origin: 100% 0;\n        margin: 0;\n    }\n    \n    .p-badge-dot {\n        width: .5rem;\n        min-width: .5rem;\n        height: .5rem;\n        border-radius: 50%;\n        padding: 0;\n    }\n    \n    .p-badge-no-gutter {\n        padding: 0;\n        border-radius: 50%;\n    }\n}\n";
var BadgeBase = ComponentBase.extend({
  defaultProps: {
    __TYPE: "Badge",
    __parentMetadata: null,
    value: null,
    severity: null,
    size: null,
    style: null,
    className: null,
    children: void 0
  },
  css: {
    classes: classes$1,
    styles: styles2
  }
});
function ownKeys$1(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread$1(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys$1(Object(t), true).forEach(function(r2) {
      _defineProperty2(e, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r2) {
      Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e;
}
var Badge = React3.memo(React3.forwardRef(function(inProps, ref) {
  var mergeProps = useMergeProps();
  var context = React3.useContext(PrimeReactContext);
  var props = BadgeBase.getProps(inProps, context);
  var _BadgeBase$setMetaDat = BadgeBase.setMetaData(_objectSpread$1({
    props
  }, props.__parentMetadata)), ptm = _BadgeBase$setMetaDat.ptm, cx = _BadgeBase$setMetaDat.cx, isUnstyled = _BadgeBase$setMetaDat.isUnstyled;
  useHandleStyle(BadgeBase.css.styles, isUnstyled, {
    name: "badge"
  });
  var elementRef = React3.useRef(null);
  React3.useImperativeHandle(ref, function() {
    return {
      props,
      getElement: function getElement() {
        return elementRef.current;
      }
    };
  });
  var rootProps = mergeProps({
    ref: elementRef,
    style: props.style,
    className: classNames(props.className, cx("root"))
  }, BadgeBase.getOtherProps(props), ptm("root"));
  return React3.createElement("span", rootProps, props.value);
}));
Badge.displayName = "Badge";
var classes2 = {
  icon: function icon(_ref) {
    var props = _ref.props;
    return classNames("p-button-icon p-c", _defineProperty2({}, "p-button-icon-".concat(props.iconPos), props.label));
  },
  loadingIcon: function loadingIcon(_ref2) {
    var props = _ref2.props, className = _ref2.className;
    return classNames(className, {
      "p-button-loading-icon": props.loading
    });
  },
  label: "p-button-label p-c",
  root: function root3(_ref3) {
    var props = _ref3.props, size = _ref3.size, disabled = _ref3.disabled;
    return classNames("p-button p-component", _defineProperty2(_defineProperty2(_defineProperty2(_defineProperty2({
      "p-button-icon-only": (props.icon || props.loading) && !props.label && !props.children,
      "p-button-vertical": (props.iconPos === "top" || props.iconPos === "bottom") && props.label,
      "p-disabled": disabled,
      "p-button-loading": props.loading,
      "p-button-outlined": props.outlined,
      "p-button-raised": props.raised,
      "p-button-link": props.link,
      "p-button-text": props.text,
      "p-button-rounded": props.rounded,
      "p-button-loading-label-only": props.loading && !props.icon && props.label
    }, "p-button-loading-".concat(props.iconPos), props.loading && props.label), "p-button-".concat(size), size), "p-button-".concat(props.severity), props.severity), "p-button-plain", props.plain));
  }
};
var ButtonBase = ComponentBase.extend({
  defaultProps: {
    __TYPE: "Button",
    __parentMetadata: null,
    badge: null,
    badgeClassName: null,
    className: null,
    children: void 0,
    disabled: false,
    icon: null,
    iconPos: "left",
    label: null,
    link: false,
    loading: false,
    loadingIcon: null,
    outlined: false,
    plain: false,
    raised: false,
    rounded: false,
    severity: null,
    size: null,
    text: false,
    tooltip: null,
    tooltipOptions: null,
    visible: true
  },
  css: {
    classes: classes2
  }
});
function ownKeys2(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys2(Object(t), true).forEach(function(r2) {
      _defineProperty2(e, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys2(Object(t)).forEach(function(r2) {
      Object.defineProperty(e, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e;
}
var Button = React3.memo(React3.forwardRef(function(inProps, ref) {
  var mergeProps = useMergeProps();
  var context = React3.useContext(PrimeReactContext);
  var props = ButtonBase.getProps(inProps, context);
  var disabled = props.disabled || props.loading;
  var metaData = _objectSpread2(_objectSpread2({
    props
  }, props.__parentMetadata), {}, {
    context: {
      disabled
    }
  });
  var _ButtonBase$setMetaDa = ButtonBase.setMetaData(metaData), ptm = _ButtonBase$setMetaDa.ptm, cx = _ButtonBase$setMetaDa.cx, isUnstyled = _ButtonBase$setMetaDa.isUnstyled;
  useHandleStyle(ButtonBase.css.styles, isUnstyled, {
    name: "button",
    styled: true
  });
  var elementRef = React3.useRef(ref);
  React3.useEffect(function() {
    ObjectUtils.combinedRefs(elementRef, ref);
  }, [elementRef, ref]);
  if (props.visible === false) {
    return null;
  }
  var createIcon = function createIcon2() {
    var className = classNames("p-button-icon p-c", _defineProperty2({}, "p-button-icon-".concat(props.iconPos), props.label));
    var iconsProps = mergeProps({
      className: cx("icon")
    }, ptm("icon"));
    className = classNames(className, {
      "p-button-loading-icon": props.loading
    });
    var loadingIconProps = mergeProps({
      className: cx("loadingIcon", {
        className
      })
    }, ptm("loadingIcon"));
    var icon3 = props.loading ? props.loadingIcon || React3.createElement(SpinnerIcon, _extends3({}, loadingIconProps, {
      spin: true
    })) : props.icon;
    return IconUtils.getJSXIcon(icon3, _objectSpread2({}, iconsProps), {
      props
    });
  };
  var createLabel = function createLabel2() {
    var labelProps = mergeProps({
      className: cx("label")
    }, ptm("label"));
    if (props.label) {
      return React3.createElement("span", labelProps, props.label);
    }
    return !props.children && !props.label && React3.createElement("span", _extends3({}, labelProps, {
      dangerouslySetInnerHTML: {
        __html: "&nbsp;"
      }
    }));
  };
  var createBadge = function createBadge2() {
    if (props.badge) {
      var badgeProps = mergeProps({
        className: classNames(props.badgeClassName),
        value: props.badge,
        unstyled: props.unstyled,
        __parentMetadata: {
          parent: metaData
        }
      }, ptm("badge"));
      return React3.createElement(Badge, badgeProps, props.badge);
    }
    return null;
  };
  var showTooltip = !disabled || props.tooltipOptions && props.tooltipOptions.showOnDisabled;
  var hasTooltip = ObjectUtils.isNotEmpty(props.tooltip) && showTooltip;
  var sizeMapping = {
    large: "lg",
    small: "sm"
  };
  var size = sizeMapping[props.size];
  var icon2 = createIcon();
  var label = createLabel();
  var badge = createBadge();
  var defaultAriaLabel = props.label ? props.label + (props.badge ? " " + props.badge : "") : props["aria-label"];
  var rootProps = mergeProps({
    ref: elementRef,
    "aria-label": defaultAriaLabel,
    "data-pc-autofocus": props.autoFocus,
    className: classNames(props.className, cx("root", {
      size,
      disabled
    })),
    disabled
  }, ButtonBase.getOtherProps(props), ptm("root"));
  return React3.createElement(React3.Fragment, null, React3.createElement("button", rootProps, icon2, label, props.children, badge, React3.createElement(Ripple, null)), hasTooltip && React3.createElement(Tooltip, _extends3({
    target: elementRef,
    content: props.tooltip,
    pt: ptm("tooltip")
  }, props.tooltipOptions)));
}));
Button.displayName = "Button";
export {
  Button
};
//# sourceMappingURL=primereact_button.js.map
